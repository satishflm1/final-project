-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: dragon
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `table_id` int DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `order_type` enum('dine_in','takeaway') NOT NULL,
  `status` enum('pending','preparing','ready','served','completed','cancelled') DEFAULT 'pending',
  `total_amount` decimal(10,2) NOT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `table_id` (`table_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`),
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,1,'Guest','dine_in','ready',859.05,1,'2025-03-25 14:00:04'),(2,1,'Guest','dine_in','pending',859.05,1,'2025-03-25 14:00:08'),(3,2,'Guest','dine_in','pending',228.85,1,'2025-03-25 14:01:21'),(4,2,'Guest','dine_in','ready',228.85,1,'2025-03-25 14:07:34'),(5,2,'Guest','dine_in','pending',846.00,1,'2025-03-25 17:36:00'),(6,3,'Guest','dine_in','pending',498.00,1,'2025-03-25 17:36:11'),(7,4,'Guest','dine_in','pending',1346.00,1,'2025-03-25 17:39:26'),(8,NULL,'sandeep','takeaway','pending',498.00,1,'2025-03-25 17:39:38'),(9,1,'Guest','dine_in','pending',1245.00,NULL,'2025-03-25 18:19:44'),(10,2,'Guest','dine_in','pending',498.00,NULL,'2025-03-25 18:32:32'),(11,2,'Customer','dine_in','pending',3085.00,NULL,'2025-03-25 19:26:06'),(12,4,'Guest','dine_in','pending',498.00,NULL,'2025-03-25 19:27:24'),(13,3,'Customer','dine_in','pending',199.00,NULL,'2025-03-25 19:28:02'),(14,1,'Guest','dine_in','pending',199.00,NULL,'2025-03-25 19:29:34'),(15,1,'Customer','dine_in','pending',498.00,NULL,'2025-03-25 19:31:07'),(16,2,'Customer','dine_in','pending',996.00,NULL,'2025-03-25 19:33:21'),(17,2,'Customer','dine_in','pending',498.00,NULL,'2025-03-25 19:41:07'),(18,1,'Customer','dine_in','pending',747.00,NULL,'2025-03-25 19:45:08'),(19,1,'Customer','dine_in','pending',498.00,NULL,'2025-03-25 19:51:13'),(20,2,'Customer','dine_in','pending',747.00,NULL,'2025-03-25 19:57:59'),(21,2,'Customer','dine_in','pending',149.00,NULL,'2025-03-25 20:00:45'),(22,1,'Guest','dine_in','pending',448.00,NULL,'2025-03-26 03:43:42'),(23,3,'Guest','dine_in','pending',897.00,NULL,'2025-03-26 03:46:49'),(24,4,'Guest','dine_in','pending',747.00,NULL,'2025-03-26 03:47:12'),(25,NULL,'Guest','takeaway','pending',448.00,NULL,'2025-03-26 03:49:09'),(26,5,'Guest','dine_in','pending',498.00,NULL,'2025-03-26 03:49:20'),(27,1,'Guest','dine_in','pending',747.00,NULL,'2025-03-26 03:52:28'),(28,NULL,'Guest','takeaway','pending',448.00,NULL,'2025-03-26 03:52:47'),(29,NULL,'Guest','takeaway','pending',2143.00,NULL,'2025-03-26 03:53:39'),(30,2,'Guest','dine_in','pending',498.00,NULL,'2025-03-26 03:55:32'),(31,NULL,'Guest','takeaway','pending',1446.00,NULL,'2025-03-26 03:56:20'),(32,NULL,'Guest','takeaway','pending',1047.00,NULL,'2025-03-26 03:58:24'),(33,NULL,'Guest','takeaway','pending',1495.00,NULL,'2025-03-26 04:01:31'),(34,3,'Guest','dine_in','pending',448.00,NULL,'2025-03-26 04:06:11'),(35,4,'Guest','dine_in','pending',747.00,NULL,'2025-03-26 04:09:13'),(36,5,'Guest','dine_in','pending',348.00,NULL,'2025-03-26 05:14:52'),(37,2,'Customer','dine_in','pending',149.00,NULL,'2025-03-26 05:21:16'),(38,4,'Customer','dine_in','completed',598.00,NULL,'2025-03-26 05:22:49'),(39,1,'Customer','dine_in','pending',448.00,NULL,'2025-03-26 05:36:06'),(40,NULL,'Guest','takeaway','pending',199.00,NULL,'2025-03-26 05:37:39'),(41,NULL,'Guest','takeaway','completed',199.00,NULL,'2025-03-26 05:37:51'),(42,NULL,'Guest','takeaway','pending',448.00,NULL,'2025-03-26 07:30:41'),(43,1,'Guest','dine_in','pending',747.00,NULL,'2025-03-26 07:33:11'),(44,2,'Guest','dine_in','pending',448.00,NULL,'2025-03-26 07:37:32'),(45,3,'Guest','dine_in','pending',498.00,NULL,'2025-03-26 07:46:01'),(46,4,'Guest','dine_in','pending',1.00,NULL,'2025-03-26 08:35:37'),(47,1,'Guest','dine_in','pending',149.00,NULL,'2025-03-26 09:01:42'),(48,2,'Guest','dine_in','pending',1.00,NULL,'2025-03-26 09:03:19'),(49,3,'Guest','dine_in','pending',448.00,NULL,'2025-03-26 09:14:15'),(50,NULL,'Guest','takeaway','pending',847.00,NULL,'2025-03-26 09:14:24'),(51,NULL,'Guest','takeaway','pending',448.00,NULL,'2025-03-26 09:16:49'),(52,4,'Guest','dine_in','pending',199.00,NULL,'2025-03-26 09:26:19'),(53,6,'Guest','dine_in','pending',199.00,NULL,'2025-03-26 09:28:38'),(54,5,'Guest','dine_in','pending',498.00,NULL,'2025-03-26 09:43:21'),(55,NULL,'Guest','takeaway','pending',2195.00,NULL,'2025-03-26 09:49:40'),(56,NULL,'Guest','takeaway','pending',299.00,NULL,'2025-03-26 09:51:42'),(57,NULL,'Guest','takeaway','pending',199.00,NULL,'2025-03-26 09:54:04'),(58,NULL,'Guest','takeaway','pending',89.00,NULL,'2025-03-26 09:54:13'),(59,NULL,'Guest','takeaway','pending',80.00,NULL,'2025-03-26 09:55:14'),(60,NULL,'Guest','takeaway','pending',70.00,NULL,'2025-03-26 09:56:53'),(61,NULL,'Guest','takeaway','pending',448.00,NULL,'2025-03-26 12:24:21'),(62,7,'Guest','dine_in','pending',448.00,NULL,'2025-03-26 12:40:07'),(63,1,'Guest','dine_in','ready',498.00,NULL,'2025-03-26 12:44:06'),(64,2,'Guest','dine_in','pending',498.00,NULL,'2025-03-26 12:47:31'),(65,3,'Guest','dine_in','preparing',448.00,NULL,'2025-03-26 12:51:08'),(66,4,'Guest','dine_in','completed',299.00,NULL,'2025-03-26 12:53:23'),(67,5,'Guest','dine_in','completed',199.00,NULL,'2025-03-26 12:56:57'),(68,6,'Guest','dine_in','pending',299.00,NULL,'2025-03-26 13:01:21'),(69,7,'Guest','dine_in','pending',448.00,NULL,'2025-03-26 13:04:37'),(70,1,'Guest','dine_in','pending',199.00,NULL,'2025-03-26 13:06:59'),(71,2,'Guest','dine_in','pending',199.00,NULL,'2025-03-26 13:09:25'),(72,3,'Guest','dine_in','pending',498.00,NULL,'2025-03-26 13:11:49'),(73,1,'Guest','dine_in','pending',498.00,NULL,'2025-03-27 04:22:42'),(74,2,'Guest','dine_in','pending',199.00,NULL,'2025-03-27 04:49:03'),(75,NULL,'Guest','takeaway','pending',448.00,NULL,'2025-03-27 04:50:31');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-27 12:46:04
