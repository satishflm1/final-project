-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: dragon
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dishes`
--

DROP TABLE IF EXISTS `dishes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dishes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category_id` int DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text,
  `available` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `dishes_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dishes`
--

LOCK TABLES `dishes` WRITE;
/*!40000 ALTER TABLE `dishes` DISABLE KEYS */;
INSERT INTO `dishes` VALUES (1,'Spring Rolls',1,199.00,'Crispy vegetable rolls served with sweet chili sauce',1,'2025-03-25 13:59:26'),(2,'Chicken Wings',1,299.00,'Spicy chicken wings with blue cheese dip',1,'2025-03-25 13:59:26'),(3,'Bruschetta',1,249.00,'Toasted bread with tomatoes, garlic, and basil',1,'2025-03-25 13:59:26'),(4,'Grilled Salmon',2,599.00,'Fresh salmon with seasonal vegetables',1,'2025-03-25 13:59:26'),(5,'Beef Tenderloin',2,799.00,'Premium beef with mushroom sauce',1,'2025-03-25 13:59:26'),(6,'Vegetable Curry',2,399.00,'Mixed vegetables in coconut curry sauce',1,'2025-03-25 13:59:26'),(7,'Chocolate Cake',3,299.00,'Rich chocolate cake with ganache',1,'2025-03-25 13:59:26'),(8,'Ice Cream Sundae',3,199.00,'Vanilla ice cream with hot fudge and nuts',1,'2025-03-25 13:59:26'),(9,'Apple Pie',3,249.00,'Warm apple pie with cinnamon',1,'2025-03-25 13:59:26'),(10,'Fresh Juice',4,149.00,'Daily fresh fruit juice',1,'2025-03-25 13:59:26'),(11,'Coffee',4,199.00,'Premium coffee with milk',1,'2025-03-25 13:59:26'),(12,'Green Tea',4,149.00,'Japanese green tea',1,'2025-03-25 13:59:26'),(13,'water bottle',8,1.00,'Cooling water bottle',1,'2025-03-26 08:35:23'),(14,'shezwan',8,89.00,'',1,'2025-03-26 09:53:57'),(15,'dub biriyani',2,80.00,'',1,'2025-03-26 09:54:34'),(16,'sddd',3,80.00,'',1,'2025-03-26 09:54:59'),(17,'adD',1,70.00,'',1,'2025-03-26 09:56:04'),(18,'manikranth',2,60.00,'',1,'2025-03-26 09:56:48');
/*!40000 ALTER TABLE `dishes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-27 12:46:05
